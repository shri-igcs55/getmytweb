<!-- ### OUR SERVICES ### -->
<section id="servicesBannerImage" class="staticPageBannerSection">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="commonWhiteContent">
					<h1>Our Services</h1>
					<span>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</span>
					<span>Lorem Ipsum has been the industry's.</span>
				</div>
			</div>
		</div>
	</div>
</section>
<section class="seviceComnContent">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h1 class="text-center">Our Services</h1>
				<p>
					Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. text of the printing and typesetting industry. 
				</p>
			</div>
		</div>
	</div>
</section>
<section class="row-column">
	<div class="container-fluid">
		<ul class="list-unstyled no-margin-list">
			<li>
				<div class="row">
					<div class="col-md-6 col-lg-6">
						<div class="img-place-content">
							<div class="width_80_per">
								<h3>Hire Trucks</h3>
								<p>
									It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here &amp; making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here &amp; making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum.The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here &amp; making it look like readable 
								</p>
							</div>
						</div>
					</div>
					<div class="col-md-6 col-lg-6">
						<div class="img-place">
							<img src="<?php echo base_url('assets/'); ?>images/hire-truck.jpg" class="img-responsive" alt="">
						</div>
					</div>
				</div>
			</li>
			<li>
				<div class="row">
					<div class="col-md-6 col-lg-6">
						<div class="img-place">
							<img src="<?php echo base_url('assets/'); ?>images/packers-movers.jpg" class="img-responsive" alt="">
						</div>
					</div>
					<div class="col-md-6 col-lg-6">
						<div class="img-place-content">
							<div class="width_80_per">
								<h3>Packers &amp; Movers</h3>
								<p>
									It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here &amp; making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here &amp; making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum.The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here &amp; making it look like readable
								</p>
							</div>
						</div>
					</div>
				</div>
			</li>
			<li>
				<div class="row">
					<div class="col-md-6 col-lg-6">
						<div class="img-place-content">
							<div class="width_80_per">
								<h3>Hire Crane</h3>
								<p>
									It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here &amp; making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here &amp; making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum.The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here &amp; making it look like readable  
								</p>
							</div>
						</div>
					</div>
					<div class="col-md-6 col-lg-6">
						<div class="img-place">
							<img src="<?php echo base_url('assets/'); ?>images/hire-crane.jpg" class="img-responsive" alt="">
						</div>
					</div>
				</div>
			</li>
		</ul>
	</div>
</section>
<section class="breifContent">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="row">
					<div class="col-md-5 text-right">
						<img src="<?php echo base_url('assets/'); ?>images/cargo-truck.png" alt="">
					</div>
					<div class="col-md-7">
						<div class="right-content">
							<h3>
								Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur
							</h3>
							<p>
								It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here &amp; making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using.
							</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>