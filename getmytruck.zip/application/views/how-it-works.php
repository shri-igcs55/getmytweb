<!-- ##### HOW IT WORKS ##### -->
	<section id="howitworksBanner" class="staticPageBannerSection">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="howItHead">
						<h1>How it works</h1>
						<span>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</span>
						<span>Lorem Ipsum has been the industry's.</span>
					</div>
				</div>
			</div>
		</div>
	</section>
	<section id="howitTimeline">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="howitTimelineContent">
						<h3 class="text-center">How It Works</h3>
						<div class="row timelinerows">
							<div class="col-md-12">
								<div class="row">
									<div class="col-md-6 rightBorderOnly"></div>
								</div>
								<div class="row first_row">
									<div class="col-md-6 rightBorder">
										<h1>1</h1>
										<img src="<?php echo base_url('assets/');?>images/order_red.png" alt="">
										<div class="width_80_per">
											<h5>Book Online</h5>
											<h2>Just a few Clicks on your computer or mobile</h2>
											<p>
												It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here &amp; making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here &amp; making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum.
											</p>
										</div>
									</div>
								</div>
								<div class="row second_row">
									<div class="col-md-6 col-md-push-6 leftBorder">
										<h1>2</h1>
										<img src="<?php echo base_url('assets/');?>images/quotation_red.png" alt="">
										<div class="width_80_per">
											<h5>Get Quotation</h5>
											<h2>Choose location, Date &amp; Time to get best discount in priority</h2>
											<p>
												It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here &amp; making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here &amp; making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum.
											</p>
										</div>
									</div>
								</div>
								<div class="row third_row">
									<div class="col-md-6 rightBorder">
										<h1>3</h1>
										<img src="<?php echo base_url('assets/');?>images/truck_red.png" alt="">
										<div class="width_80_per">
											<h5>PICK UP &amp; DELIVER</h5>
											<h2>Do what you love to do &amp; leave thepick up &amp; delivery to us</h2>
											<p>
												It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here &amp; making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here &amp; making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum.
											</p>
										</div>
									</div>
								</div>
								<div class="row fourth_row">
									<div class="col-md-6 col-md-push-6 leftBorder">
										<h1>4</h1>
										<img src="<?php echo base_url('assets/');?>images/track_red.png" alt="">
										<div class="width_80_per">
											<h5>TRACK ANYTIME</h5>
											<h2>With realtime tracking, never lose sight of your goods</h2>
											<p>
												It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here &amp; making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here &amp; making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum.
											</p>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>