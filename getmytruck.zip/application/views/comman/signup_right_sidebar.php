<div class="custmr_reg_right">

	<div class="usr_login">
		<div class="section_sub">
			<h3>Already <span>Details</span></h3>
			<h4><a href="<?php echo site_url('user/signin/'); ?>">Click here to Login</a></h4>
		</div>
	</div>

	<div class="reg_option">
		<div class="section_sub">
			<h3>Basic <span>Details</span></h3>
			
		</div>

		<ul>
			<li>
				<a href="<?php echo site_url('user/customer/'); ?>">Customer Registration</a>
			</li>
			<li>
				<a href="<?php echo site_url('user/transporter_logistic/'); ?>">Transport Registration</a>
			</li>
			<li>
				<a href="<?php echo site_url('user/packer_mover/'); ?>">Packers and Mover Registration</a>
			</li>
			<li>
				<a href="<?php echo site_url('user/crane_provider/'); ?>">Crane Provider Registration</a>
			</li>

		</ul>
	</div>

</div>