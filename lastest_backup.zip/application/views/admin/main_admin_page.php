
        <div id="page-wrapper" >
          <div id="page-inner">
            <!-- <div class="row">
                <div class="col-md-12">
                 <h2>Admin Dashboard</h2>   
                    <h5>Welcome <?php //echo $user_id_admin;?>, Nice to see you back. </h5>
                </div>
            </div>  -->
            <!-- /. ROW  -->
            <!-- <hr /> -->
            <div class="row">
           
	          </div>
            <!-- /. ROW  -->           
          </div>
          <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->