<section class="sign-up-page custmer_reg">
	<div class="container">
		<div class="row signup-form-wrp">

			<article class="col-md-6 pad-rit-0">

				<div class="signup-wrp">

					<center><h1>Create your account today for <span>FREE</span></h1></center>

					<div class="creat_free">

						<div class="row">
							<article class="col-xs-3 pad-rit-0">
								<div >
								<br>
									<img src="<?php echo base_url('assets/');?>images/creat-ac.png" class="img-responsive">
									<div style="clear:both"></div>
								</div>
							</article>
							<article class="col-xs-9">
								<div class="">
									<br>
									<p>getmytruck.in is an online portal where customers can post their requirements and can get best solutions for their requirements.</p>
								</div>
							</article>
						</div>

					</div>

					<div class="creat_free">
					
						<div class="row">
							<article class="col-xs-3 pad-rit-0">
								<div >
								<br>
									<img src="<?php echo base_url('assets/');?>images/creat-ac.png" class="img-responsive">
									<div style="clear:both"></div>
								</div>
							</article>
							<article class="col-xs-9">
								<div class="">
									<br>
									<p>we provide a platform where goods transporters
									 (transporters &amp; logistics, container providers, trolley or tankers providers, fleet owner, commission agents) and service provider(packers movers &amp; crane provider) can grow their business by satisfying most number of customers.</p>
								</div>
							</article>
						</div>

					</div>

					<div class="creat_free">
					
						<div class="row">
							<article class="col-xs-3 pad-rit-0">
								<div >
								<br>
									<img src="<?php echo base_url('assets/');?>images/creat-ac.png" class="img-responsive">
									<div style="clear:both"></div>
								</div>
							</article>
							<article class="col-xs-9">
								<div class="">
									<br>
									<p>We provide the information about availability of goods or requirement of services  to registered users.</p>
								</div>
							</article>
						</div>

					</div>
					

				</div>

			</article>

			<article class="col-md-6">

				<div class="signup-as-wrp">

					<center><h1>Sign up as</h1></center>

					<ul class="signUpAs_each-wrp">

						<li class=" active">
							<div class="signUpAs_each">
								<div class="LEft">
									<img src="<?php echo base_url('assets/');?>images/customer.png" alt="">
									<p>Customer</p>
								</div>
								<div class="MIdle">
									<p>Register, place order and get quotes from many vendors.</p>
								</div>
								<div class="RIght">
									<a href="<?php echo site_url('user/customer/'); ?>"><button>Register Now</button></a>
								</div>
								<span><img src="<?php echo base_url('assets/');?>images/right_arw.png"></span>
								<div style="clear:both;"></div>
							</div>
						</li>

						<li class=" ">
							<div class="signUpAs_each">
								<div class="LEft">
									<img src="<?php echo base_url('assets/');?>images/mover.png" alt="">
									<p>Transporter &amp; Logistics</p>
								</div>
								<div class="MIdle">
									<p>Register to grow business by finding more customers.</p>
								</div>
								<div class="RIght">
									<a href="<?php echo site_url('user/transporter_logistic/'); ?>"><button>Register Now</button></a>
								</div>
								<span><img src="<?php echo base_url('assets/');?>images/right_arw.png"></span>
								<div style="clear:both;"></div>
							</div>
						</li>
						<li class=" ">
							<div class="signUpAs_each">
								<div class="LEft">
									<img src="<?php echo base_url('assets/');?>images/pack.png" alt="">
									<p>Packers &amp; Movers</p>
								</div>
								<div class="MIdle">
									<p>Register to grow business by finding more customers.</p>
								</div>
								<div class="RIght">
									<a href="<?php echo site_url('user/packer_mover/'); ?>"><button>Register Now</button></a>
								</div>
								<span><img src="<?php echo base_url('assets/');?>images/right_arw.png"></span>
								<div style="clear:both;"></div>
							</div>
						</li>
						<li class=" ">
							<div class="signUpAs_each">
								<div class="LEft">
									<img src="<?php echo base_url('assets/');?>images/crane.png" alt="">
									<p>Crane Providers</p>
								</div>
								<div class="MIdle">
									<p>Register to grow business by finding more customers.</p>
								</div>
								<div class="RIght">
									<a href="<?php echo site_url('user/crane_provider/'); ?>"><button>Register Now</button></a>
								</div>
								<span><img src="<?php echo base_url('assets/');?>images/right_arw.png"></span>
								<div style="clear:both;"></div>
							</div>
						</li>

					</ul>

				</div>

			</article>

		</div>
	</div>
</section>